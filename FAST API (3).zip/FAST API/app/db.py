"""Database engine and session management (SQLAlchemy).

- Creates an engine from DATABASE_URL
- Provides a scoped session dependency for FastAPI routes
- Declarative Base for ORM models
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base, Session

from .config import get_settings


settings = get_settings()
# Engine works with PostgreSQL (psycopg2) or SQLite (pysqlite) depending on DATABASE_URL
engine = create_engine(settings.database_url, echo=False, future=True)
# Session factory; expire_on_commit=False keeps attributes accessible after commit
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False, future=True)
# Base class for ORM models
Base = declarative_base()


def get_db() -> Session:
	"""FastAPI dependency yielding a DB session per request."""
	db = SessionLocal()
	try:
		yield db
	finally:
		db.close() 