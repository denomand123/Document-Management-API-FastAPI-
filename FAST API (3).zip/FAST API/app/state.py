from .services.embeddings_store import InMemoryEmbeddingsStore

embeddings_store = InMemoryEmbeddingsStore() 